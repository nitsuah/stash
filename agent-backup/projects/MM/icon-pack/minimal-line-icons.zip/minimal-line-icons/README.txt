41 line icons, 24x24 grid, 2px stroke, currentColor (inherits your text color).
svg/ folder: one file per icon. Open preview.html to browse.
Tip: change stroke-width or stroke in the SVG to restyle.
